package com.example.suzu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {
    private RecyclerView eventsGrid;
    private View emptyStateView;
    private EventAdapter adapter;
    private List<Event> events = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize views
        eventsGrid = findViewById(R.id.eventsGrid);
        emptyStateView = findViewById(R.id.emptyStateView);
        ExtendedFloatingActionButton addEventButton = findViewById(R.id.addEventButton);

        // Setup RecyclerView
        eventsGrid.setLayoutManager(new GridLayoutManager(this, 1));
        adapter = new EventAdapter(events);
        eventsGrid.setAdapter(adapter);

        // Setup FAB click listener
        addEventButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        // Load events and update UI
        loadEvents();
    }

    private void loadEvents() {
        // TODO: Load events from database
        // For now, just check if we have any events
        updateEmptyState();
    }

    private void updateEmptyState() {
        if (events.isEmpty()) {
            eventsGrid.setVisibility(View.GONE);
            emptyStateView.setVisibility(View.VISIBLE);
        } else {
            eventsGrid.setVisibility(View.VISIBLE);
            emptyStateView.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }
} 