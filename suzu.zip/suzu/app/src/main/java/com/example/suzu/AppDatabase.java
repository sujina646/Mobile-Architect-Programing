package com.example.suzu;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// This is a  main database class
@Database(entities = {User.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    // We only want one database instance
    private static AppDatabase instance;
    
    // This gives  access to user operations
    public abstract UserDao userDao();

    // Get database instance
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            // Create database if it doesn't exist
            instance = Room.databaseBuilder(
                context.getApplicationContext(),
                AppDatabase.class,
                "event_tracker_db"
            ).build();
        }
        return instance;
    }
} 