package com.example.suzu;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// This class represents a user in our database
@Entity(tableName = "users")
public class User {
    // Each user gets a unique ID
    @PrimaryKey(autoGenerate = true)
    private int id;
    
    // Username and password for login
    private String username;
    private String password;

    // Constructor to create a new user
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
} 