package com.example.suzu;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// This class helps us handle SMS permissions and sending messages
public class SmsHelper {
    // Permission request code
    private static final int SMS_PERMISSION_CODE = 123;
    
    // Check if we have SMS permission
    public static boolean hasSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, 
            Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }
    
    // Ask user for SMS permission
    public static void requestSmsPermission(Activity activity) {
        ActivityCompat.requestPermissions(activity,
            new String[]{Manifest.permission.SEND_SMS},
            SMS_PERMISSION_CODE);
    }
    
    // Send an SMS message
    public static void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
} 