package com.example.suzu;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    // UI elements
    private EditText usernameField;
    private EditText passwordField;
    private EditText phoneNumberField;  // New field for phone number
    private Button loginButton;
    private Button registerButton;
    
    // Database and background thread
    private AppDatabase db;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up database and background thread
        db = AppDatabase.getInstance(this);
        executorService = Executors.newSingleThreadExecutor();

        // Find our UI elements
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        phoneNumberField = findViewById(R.id.phoneNumberField);  // New field
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Set up button clicks
        loginButton.setOnClickListener(v -> tryLogin());
        registerButton.setOnClickListener(v -> tryRegister());

        // Check for SMS permission
        if (!SmsHelper.hasSmsPermission(this)) {
            SmsHelper.requestSmsPermission(this);
        }
    }

    // Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, 
                                         @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == 123) {  // SMS permission code
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications won't work.", 
                    Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Try to log in
    private void tryLogin() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();
        String phoneNumber = phoneNumberField.getText().toString().trim();

        // Check if fields are empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Try to log in on background thread
        executorService.execute(() -> {
            User user = db.userDao().login(username, password);
            runOnUiThread(() -> {
                if (user != null) {
                    // Login worked!
                    Toast.makeText(MainActivity.this, "Welcome back!", Toast.LENGTH_SHORT).show();
                    
                    // If we have phone number and SMS permission, save it
                    if (!phoneNumber.isEmpty() && SmsHelper.hasSmsPermission(this)) {
                        // TODO: Save phone number to user preferences
                        Toast.makeText(MainActivity.this, 
                            "SMS notifications enabled for: " + phoneNumber, 
                            Toast.LENGTH_SHORT).show();
                    }
                    
                    startActivity(new Intent(MainActivity.this, DashboardActivity.class));
                    finish();
                } else {
                    // Login failed
                    Toast.makeText(MainActivity.this, "Wrong username or password", 
                        Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // Try to register
    private void tryRegister() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        // Check if fields are empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if username exists on background thread
        executorService.execute(() -> {
            User existingUser = db.userDao().getUserByUsername(username);
            runOnUiThread(() -> {
                if (existingUser != null) {
                    Toast.makeText(MainActivity.this, "Username already taken", Toast.LENGTH_SHORT).show();
                } else {
                    // Create new user
                    User newUser = new User(username, password);
                    executorService.execute(() -> {
                        db.userDao().register(newUser);
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "Account created!", Toast.LENGTH_SHORT).show();
                        });
                    });
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
} 