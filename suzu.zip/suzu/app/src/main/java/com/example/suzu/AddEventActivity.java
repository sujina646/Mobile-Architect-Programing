package com.example.suzu;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBar;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.slider.Slider;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

public class AddEventActivity extends AppCompatActivity {
    private TextInputEditText titleField;
    private TextInputEditText dateField;
    private TextInputEditText timeField;
    private TextInputEditText locationField;
    private AutoCompleteTextView categorySpinner;
    private TextInputEditText descriptionField;
    private Slider reminderSlider;
    private MaterialButton saveButton;
    private MaterialButton cancelButton;
    private Calendar selectedDateTime;
    private final SimpleDateFormat dateFormatter = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
    private final SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm a", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialize UI components
        initializeViews();
        setupToolbar();
        setupDateTimePickers();
        setupCategorySpinner();
        setupReminderSlider();
        setupButtons();
    }

    private void initializeViews() {
        titleField = findViewById(R.id.titleField);
        dateField = findViewById(R.id.dateField);
        timeField = findViewById(R.id.timeField);
        locationField = findViewById(R.id.locationField);
        categorySpinner = findViewById(R.id.categorySpinner);
        descriptionField = findViewById(R.id.descriptionField);
        reminderSlider = findViewById(R.id.reminderSlider);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        selectedDateTime = Calendar.getInstance();
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
        }
    }

    private void setupDateTimePickers() {
        if (dateField != null) {
            dateField.setOnClickListener(v -> showDatePicker());
        }
        if (timeField != null) {
            timeField.setOnClickListener(v -> showTimePicker());
        }

        // Set initial date and time
        updateDateField();
        updateTimeField();
    }

    private void setupCategorySpinner() {
        if (categorySpinner != null) {
            String[] categories = {"Personal", "Work", "Study", "Family", "Other"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_dropdown_item_1line,
                    categories
            );
            categorySpinner.setAdapter(adapter);
            // Set default category
            categorySpinner.setText(categories[0], false);
        }
    }

    private void setupReminderSlider() {
        if (reminderSlider != null) {
            reminderSlider.setLabelFormatter(value -> 
                value == 0 ? "No reminder" : 
                value == 1 ? "1 day before" : 
                String.format(Locale.getDefault(), "%.0f days before", value)
            );
        }
    }

    private void setupButtons() {
        if (saveButton != null) {
            saveButton.setOnClickListener(v -> saveEvent());
        }
        if (cancelButton != null) {
            cancelButton.setOnClickListener(v -> finish());
        }
    }

    private void showDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    selectedDateTime.set(Calendar.YEAR, year);
                    selectedDateTime.set(Calendar.MONTH, month);
                    selectedDateTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDateField();
                },
                selectedDateTime.get(Calendar.YEAR),
                selectedDateTime.get(Calendar.MONTH),
                selectedDateTime.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void showTimePicker() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    selectedDateTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedDateTime.set(Calendar.MINUTE, minute);
                    updateTimeField();
                },
                selectedDateTime.get(Calendar.HOUR_OF_DAY),
                selectedDateTime.get(Calendar.MINUTE),
                false
        );
        timePickerDialog.show();
    }

    private void updateDateField() {
        if (dateField != null) {
            dateField.setText(dateFormatter.format(selectedDateTime.getTime()));
        }
    }

    private void updateTimeField() {
        if (timeField != null) {
            timeField.setText(timeFormatter.format(selectedDateTime.getTime()));
        }
    }

    private void saveEvent() {
        // Validate input fields
        String title = titleField != null ? Objects.requireNonNull(titleField.getText()).toString().trim() : "";
        if (title.isEmpty()) {
            if (titleField != null) {
                titleField.setError("Title is required");
            }
            return;
        }

        // For now, just show a success message
        Toast.makeText(this, "Event saved successfully", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}