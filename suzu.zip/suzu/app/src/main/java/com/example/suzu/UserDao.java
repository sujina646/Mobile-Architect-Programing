package com.example.suzu;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

// This interface handles all database operations for users
@Dao
public interface UserDao {
    // Check if username and password match
    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    User login(String username, String password);

    // Check if username already exists
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByUsername(String username);

    // Add a new user
    @Insert
    void register(User user);
} 